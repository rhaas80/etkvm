#!/bin/bash

sudo btrfs filesystem resize max /
xmessage "Resized to $(df -h | awk '/sda1/{print $2}')"
